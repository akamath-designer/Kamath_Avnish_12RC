# Preseason Digital Notebook Example
Name: **[INSERT NAME HERE]**

Section: **[I2RC/ARC]**

Week: **[INSERT WEEK NUM HERE]**


## Code

The main topic this week was: **[TOPIC NAME]**

Commands: **[COMMANDS]**

Subsystems: **[SUBSYSTEMS]**

### How does the code work?
Write about how it works here


### Important notes for future reference
Notes about git, and helpful resources, etc. 

Please put them here, they will really help you in the future 